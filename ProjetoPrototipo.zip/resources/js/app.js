
import.meta.glob([
    '../img/**',
    '../fonts/**',
  ]);
