<?php

use App\Http\Controllers\DoadorController;
use App\Http\Controllers\OngController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// publicos

Route::get('/cadastrarDoador', [DoadorController::class, 'cadastrarDoadorView']);

Route::post('/cadastraOng', [DoadorController::class, 'cadastrarDoador']);

Route::get('/cadastrarOng', [OngController::class, 'cadastrarOngView']);

Route::post('/cadastrarDoador', [OngController::class, 'cadastrarOng']);

Route::get('/logout', function(){
    Auth::guard('Doador')->logout();
    Auth::guard('Ong')->logout();
});

Route::get('/login', function(){
    return "login";
})->name('login');

Route::get('/CadastrarOng', function(){
    return view('cadastrarOng');
})->name('login');

Route::get('/informacoes', function(){
    return view('Telas.informacoes');
})->name("Informacoes");

Route::get('/necessidade', function(){
    return view('Telas.ListarConteudoNecessidade');
});


Route::get('/ListaNecessidades', function(){
    return view('Telas2.listaNecessidades');
})->name("ListarNecessidades");

Route::get('/PesquisarNecessidades', function(){
    return view('Telas2.Pesquisar_Necessidade');
});

Route::get('/LogoutEfetuado', function(){
    return view('Telas3.logoutefetuado');
});
Route::get('/RecuperarSenha', function(){
    return view('Telas3.RecuperacaoSenha');
});
Route::get('/RecuperarSenha2', function(){
    return view('Telas3.recuperacaodesenha2');
});
Route::get('/VerificarEmail', function(){
    return view('Telas3.verificacaodeemail');
});

Route::get('/AtualizarContaDoador', function(){
    return view('Telas.AtualizarContaDoador');
})->name("AtualizarDoador");;
Route::get('/AtualizarContaOng', function(){
    return view('Telas.AtualizarONG');
});
Route::get('/AtualizarNecessidade', function(){
    return view('Telas.AtualizarNecessidade');
});
Route::get('/CadastrarNecessidade', function(){
    return view('Telas.CadastrarNecessidade');
});

Route::get('/DoacoesRealizadas', function(){
    return view('Telas.DoacoesRealizadas');
})->name("DoacoesRealizadas");

Route::get('/DoacoesRecebidas', function(){
    return view('Telas.DoacoesRecebidas');
})->name("DoacoesRecebidas");

Route::get('/NecessidadesDaOng', function(){
    return view('Telas.NecessidadesDaOng');
})->name("NecessidadesDaOng");

Route::get('/', function(){
    return view('index');
})->name("home");
    
Route::get('/homeOng', function(){
return view('indexOng');
})->middleware('auth:Doador');

Route::get('/notificacoes', function(){
    return view('Telas.Notificacoes');
});

Route::get('/DoacaoMaterialEnviada', function(){
    return view('Telas.DoacaoMaterialEnviada');
});

Route::get('/DoacaoMonetariaEnviada', function(){
    return view('Telas.DoacaoMonetariaEnviada');
});


Route::get('/RealizarDoacaoMaterial', function(){
    return view('Telas.RealizarDoacaoMaterial');
})->name("RealizarDoacaoMaterial");

Route::get('/ConfirmarEmailDoador', function(){
    return view('Telas2.Confimar_E-mail_Doador');
});

Route::get('/ConfirmarDesativacaoDoador', function(){
    return view('Telas2.Confirmar_Desativacao_Doador');
});

Route::get('/DesativarContaDoador', function(){
    return view('Telas2.Desativar_Conta_Doador');
});

Route::get('/RealizarPagamento', function(){
    return view('Telas.MeioDePagamento');
})->name("MeioPagamento");

Route::get('/DoacaoDesativada', function(){
    return view('Telas2.Doacao_Desativada');
});

Route::get('/DesativarDoacao', function(){
    return view('Telas2.Desativar_Doacao');
})->name("DesativarNecessidade");

Route::get('/RealizarDoacaoMonetaria', function(){
    return view('Telas.RealizarDoacaoMonetaria');
});

Route::get('/ConfirmarEmailOng', function(){
    return view('Telas2.ConfirmarEmailOng');
});
    
Route::get('/listarOngs', function(){
    return view('Telas2.Lista_ONGs');
})->name("ListarONGs");

Route::get('/ConfirmarDesativacaoOng', function(){
    return view('Telas2.Confirmar_Desativacao_ONG');
});

Route::get('/DesativarContaOng', function(){
    return view('Telas2.Desativar_Conta_ONG');
});

    
Route::get('/ContaDesativada', function(){
    return view('Telas2.Conta_Desativada');
});

Route::get('/DoacaoMaterialRecebida', function(){
    return view('Telas.DoacaoMaterialRecebida');
});

Route::get('/DoacaoMonetariaRecebida', function(){
    return view('Telas.DoacaoMonetariaRecebida');
});

Route::get('/DesativarNecessidade', function(){
    return view('Telas3.desativarnecessidade');
});

Route::get('/DesativarNecessidade2', function(){
    return view('Telas3.desativarnecessidade2');
})->name("DesativarNecessidade2");

Route::get('/homeOng', function(){
    return view('Telas3.homeong');
});

Route::get('/ListarConversas', function(){
    return view('Telas.ListarConversas');
})->name("ListarConversas");

Route::get('/TelaChat', function(){
    return view('Telas.TelaChat');
});

