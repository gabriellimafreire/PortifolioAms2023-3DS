<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    
        <?php echo app('Illuminate\Foundation\Vite')([
        'resources/css/app.css', 
        'resources/js/app.js',
        'resources/css/homeong.css', 
        'node_modules/bootstrap/dist/css/bootstrap.min.css',
        'node_modules/bootstrap/dist/js/bootstrap.bundle.js'
        ]); ?>
   <title>HOME ONG | BY HOPE IN LIFE</title>

   <header><!--cabecalho-->   
<nav class="navbar navbar-expand-lg" style="background:#41BFB3">
        
        <div class="container-fluid">
          <a class="navbar-brand" href="<?php echo e(Route('home')); ?>"><img src="<?php echo e(Vite::asset('resources/img/HL - Logotipo - SEM LETREIRO.png')); ?>" class="logo"></a>
          
                  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation" hidden>
                  <span class="navbar-toggler-icon"></span>
                  </button>
      
                  
              <div id="divBusca"><input class="form-control" type="search" placeholder="Pesquisar..." aria-label="Search"></div>  
              <ul class="nav nav-underline" id="">
              <li class="nav-item">
                      <a class="nav-link" aria-current="page" href="<?php echo e(Route('home')); ?>">Home</a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link" aria-current="page" href="<?php echo e(Route('DoacoesRealizadas')); ?>">Minhas doações</a>
                  </li>

                  <li class="nav-item">
                      <a class="nav-link" href="<?php echo e(Route('ListarONGs')); ?>">As ONGs</a>
                  </li>

                  <li class="nav-item">
                      <a class="nav-link" href="<?php echo e(Route('ListarNecessidades')); ?>">Necessidades</a>
                  </li>

                  <li class="nav-item">
                      <a class="nav-link" href="<?php echo e(Route('ListarConversas')); ?>">Chat</a>
                  </li>
                  <li class="nav-item">
                    <div class="dropdown" >
                        <button class="btn btn-secondary" type="button" style="background-color: #41BFB3;" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                            <a href=""><img src="<?php echo e(Vite::asset('resources/img/setaparabaixo.ico')); ?>" class="setab"></a>
                            <a href=""><img src="<?php echo e(Vite::asset('resources/img/usuario.ico')); ?>" class="users"></a>
                        </button>
                        <ul class="dropdown-menu" >
                        <li><a class="dropdown-item" href="#">Perfil</a></li>
                        <li><a class="dropdown-item" href="#">Dados de pagamento</a></li>
                        <li><a class="dropdown-item" href="#"></a></li>
                        </ul>
                    </div>
                  </li>
                  <li class="nav-item">
                    <a href=""><img src="<?php echo e(Vite::asset('resources/img/notificacao.ico')); ?>" class="notification"></a>
                  </li>
             </ul>
       </div>
      </nav>
</header>


</head>
<body class="body"><br>
    <h4 style="color: #275950;">Bem vindo!</h4><br>
    <h6 style="color: #275950;" class="title">Minhas necessidades</h6>

    <div class="card1">
<center><div class="row">
            <div class="col">
              <div class="card" style="background-color: #9BF2EA;">
                <center><b style="color: #275950;">Arrecadação de Alimentos</b></center>
                <div class="necessidade">
                <center><img src="<?php echo e(Vite::asset('resources/img/cestadealimentos.jpeg')); ?>"  alt="cestadealimentos"></center>
                <h3>Tipo:</h3><b style="color: #275950;"> Material</b><br>
                <p>Arrecadação de alimentos para as comunidades na região do Itaquera.
                    Pedimos por alimentos não perecíveis.
                    Mais informações, contate-nos.</p>
                    <center><h6>Meta: 7/25</h6></center>
                </div>
              </div>
            </div>
            <div class="col">
                <div class="card" style="background-color: #9BF2EA;">
                    <center><b style="color: #275950;">Arrecadação de Alimentos</b></center>
                    <div class="necessidade">
                    <center><img src="<?php echo e(Vite::asset('resources/img/roupadeinverno.jpeg')); ?>"  alt="cestadealimentos"></center>
                    <h3>Tipo:</h3><b style="color: #275950;"> Monetária</b><br>
                   <p>Capanha do agasalho.
                    Arrecadação monetária para reparo ou compra de novos agasalhos para doação.</p>
                        <center><h6>Meta: R$40,00/R$100,00</h6></center>
                    </div><br>
                  </div>
            </div>
            <div class="col">
                <div class="card" style="background-color: #9BF2EA;">
                    <center><b style="color: #275950;">Arrecadação de Alimentos</b></center>
                    <div class="necessidade">
                    <center><img src="<?php echo e(Vite::asset('resources/img/cestadealimentos.jpeg')); ?>"  alt="cestadealimentos"></center>
                    <h3>Tipo:</h3><b style="color: #275950;"> Material</b><br>
                    <p>Arrecadação de alimentos para as comunidades na região do Itaquera.
                        Pedimos por alimentos não perecíveis.
                        Mais informações, contate-nos.</p>
                        <center><h6>Meta: 7/25</h6></center>
                    </div>
                  </div>
            </div>
          </div></center>
    </div><br><br>


    <h6 style="color: #275950;" class="title">Doações recebidas</h6>

    <div class="card1">
<center><div class="row">
            <div class="col">
              <div class="card" style="background-color: #9BF2EA;">
                <center><b style="color: #275950;">Arrecadação de Alimentos</b></center>
                <div class="necessidade">
                <center><img src="<?php echo e(Vite::asset('resources/img/cestadealimentos.jpeg')); ?>"  alt="cestadealimentos"></center>
                <h3>Tipo:</h3><b style="color: #275950;"> Material</b><br>
                <p>Arrecadação de alimentos para as comunidades na região do Itaquera.
                    Pedimos por alimentos não perecíveis.
                    Mais informações, contate-nos.</p>
                    <center><h6>Meta: 7/25</h6></center>
                </div>
              </div>
            </div>
            <div class="col">
                <div class="card" style="background-color: #9BF2EA;">
                    <center><b style="color: #275950;">Arrecadação de Alimentos</b></center>
                    <div class="necessidade">
                    <center><img src="<?php echo e(Vite::asset('resources/img/roupadeinverno.jpeg')); ?>"  alt="cestadealimentos"></center>
                    <h3>Tipo:</h3><b style="color: #275950;"> Monetária</b><br>
                   <p>Capanha do agasalho.
                    Arrecadação monetária para reparo ou compra de novos agasalhos para doação.</p>
                        <center><h6>Meta: R$40,00/R$100,00</h6></center>
                    </div><br>
                  </div>
            </div>
            <div class="col">
                <div class="card" style="background-color: #9BF2EA;">
                    <center><b style="color: #275950;">Arrecadação de Alimentos</b></center>
                    <div class="necessidade">
                    <center><img src="<?php echo e(Vite::asset('resources/img/cestadealimentos.jpeg')); ?>"  alt="cestadealimentos"></center>
                    <h3>Tipo:</h3><b style="color: #275950;"> Material</b><br>
                    <p>Arrecadação de alimentos para as comunidades na região do Itaquera.
                        Pedimos por alimentos não perecíveis.
                        Mais informações, contate-nos.</p>
                        <center><h6>Meta: 7/25</h6></center>
                    </div>
                  </div>
            </div>
          </div></center>
    </div>










<br><br><br><br><br><br>
    
</body>
<footer class="main-footer">
        <a class="QS" href="<?php echo e(Route('Informacoes')); ?>">Quem somos?</a>
        <a class="Info" href="<?php echo e(Route('Informacoes')); ?>">Informações</a>
        <a href=""><img src="<?php echo e(Vite::asset('resources/img/instagram.png')); ?>" class="img1-footer"></a>
        <a href=""><img src="<?php echo e(Vite::asset('resources/img/linkedin.png')); ?>" class="img2-footer"></a>
       </footer>
</html><?php /**PATH C:\Users\guilherme\Hope_in_Life\Projeto_TCC_Hope_In_Life\resources\views/Telas3/homeong.blade.php ENDPATH**/ ?>