<html>
<head>

    <meta lang="pt-br">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>INDEX DOADOR | BY HOPE IN LIFE</title>

    <?php echo app('Illuminate\Foundation\Vite')([
        'resources/css/app.css', 
        'resources/css/index.css', 
        'node_modules/bootstrap/dist/css/bootstrap.min.css',
        'node_modules/bootstrap/dist/js/bootstrap.bundle.js'
        ]); ?>

</head>

<body style="background:#64CCC9">
<style>
    /* modal */

.modal-body{
    text-align: center;
}
.modal-body img{
    display: inline-block;
}
.modal-content{
    background-color: #64CCC9!important;
}
</style>

<header><!--cabecalho-->    
<nav class="navbar navbar-expand-lg" style="background:#41BFB3">
        
        <div class="container-fluid">
          <a class="navbar-brand" href="<?php echo e(Route('home')); ?>"><img src="<?php echo e(Vite::asset('resources/img/HL - Logotipo - SEM LETREIRO.png')); ?>" class="logo"></a>
          
                  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation" hidden>
                  <span class="navbar-toggler-icon"></span>
                  </button>
      
                  
              <div id="divBusca"><input class="form-control" type="search" placeholder="Pesquisar..." aria-label="Search"></div>  
              <ul class="nav nav-underline" id="">
              <li class="nav-item">
                      <a class="nav-link active" aria-current="page" href="<?php echo e(Route('home')); ?>">Home</a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link" aria-current="page" href="<?php echo e(Route('DoacoesRealizadas')); ?>">Minhas doações</a>
                  </li>

                  <li class="nav-item">
                      <a class="nav-link" href="<?php echo e(Route('ListarONGs')); ?>">As ONGs</a>
                  </li>

                  <li class="nav-item">
                      <a class="nav-link" href="<?php echo e(Route('ListarNecessidades')); ?>">Necessidades</a>
                  </li>

                  <li class="nav-item">
                      <a class="nav-link" href="<?php echo e(Route('ListarConversas')); ?>">Chat</a>
                  </li>
                  <li class="nav-item">
                    <div class="dropdown" >
                        <button class="btn btn-secondary" type="button" style="background-color: #41BFB3;" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                            <a href=""><img src="<?php echo e(Vite::asset('resources/img/setaparabaixo.ico')); ?>" class="setab"></a>
                            <a href=""><img src="<?php echo e(Vite::asset('resources/img/usuario.ico')); ?>" class="users"></a>
                        </button>
                        <ul class="dropdown-menu" >
                        <li><a class="dropdown-item" href="#">Perfil</a></li>
                        <li><a class="dropdown-item" href="#">Dados de pagamento</a></li>
                        <li><a class="dropdown-item" href="#"></a></li>
                        </ul>
                    </div>
                  </li>
                  <li class="nav-item">
                    <a href=""><img src="<?php echo e(Vite::asset('resources/img/notificacao.ico')); ?>" class="notification"></a>
                  </li>
             </ul>
       </div>
      </nav>
</header><!--cabecalho-->
<img src="<?php echo e(Vite::asset('resources/img/hope in life.png')); ?>" class="img-fluid" alt="..."  width="100%" >
<br><br>
<center><h1 style="font-family: Italianno">Necessidades</h1></center><br><br><br>

<div class="container " style="background-color:#9BF2EA; padding: 20px; border-radius: 5px;">

  <div class="row">
    <div class="col">

            <div class="card" style="width: 18rem;">
                <img src="<?php echo e(Vite::asset('resources/img/Fraldas.png')); ?>" width="250px"alt="..." height="200px">
            <div class="card-body">
                <h5 class="card-title">Fralda Geriátrica</h5>
                <p class="card-text">Necessita-se de 10 pacotes de fraldas geriátricas para doar a duas famílias de idosos.</p>
                
            </div>
        </div>

    </div>

    <div class="col">

        <div class="card" style="width: 18rem;">
                    <img src="<?php echo e(Vite::asset('resources/img/RoupasInverno.png')); ?>" width="250px"alt="..." height="200px">
                <div class="card-body">
                    <h5 class="card-title">Roupa para o Inverno</h5>
                    <p class="card-text">Estamos arrecadando agasalhos e roupas de frio em geral.
Para mais informações, entre em contato com nossa ONG.</p>
                    
                </div>
        </div>
    </div>

    <div class="col">

    <div class="card" style="width: 18rem;">
                <img src="<?php echo e(Vite::asset('resources/img/Cesta.png')); ?>" width="250px" height="200px">
            <div class="card-body">
                <h5 class="card-title">Cesta de Alimentos</h5>
                <p class="card-text">Campanha de doação de
alimentos não pereciveis</p>
            </div>
    </div>
  </div>
  </div>
</div>
</div><br><br><br><br>

<center><h1 style="font-family: Italianno">ONGs</h1></center><br><br><br><br>

<div class="container" style="background-color:#9BF2EA; border-radius: 5px !important; padding: 20px;">
  <div class="row">
    <div class="col">

            <div class="card" style="width: 18rem;">
                <img src="<?php echo e(Vite::asset('resources/img/CAF.png')); ?>" width="250px" height="240px">
            <div class="card-body">
                <h5 class="card-title">Fralda Geriátrica</h5>
                <p class="card-text">Necessita-se de 10 pacotes de fraldas geriátricas para doar a duas famílias de idosos.</p>
            </div>
        </div>

    </div>

    <div class="col">

        <div class="card" style="width: 18rem;">
                    <img src="<?php echo e(Vite::asset('resources/img/Refugio343.png')); ?>" width="250px" height="230px">
                    
                <div class="card-body">
                    <h5 class="card-title">Roupa para o Inverno</h5>
                    <p class="card-text">Estamos arrecadando agasalhos e roupas de frio em geral.
                      Para mais informações, entre em contato com nossa ONG.</p>

                </div>
        </div>
    </div>

    <div class="col">

    <div class="card" style="width: 18rem; background-color: while;">
            <div style="background-color: #4C77CC; border-radius: 150px;">
                <img src="<?php echo e(Vite::asset('resources/img/CasaRonaldMcDonald.png')); ?>" class="card-img-top" width="250px" height="230px" >
            </div>
                <div class="card-body" stule>
                <h5 class="card-title">Cesta de Alimentos</h5>
                <p class="card-text">Campanha de doação de alimentos não pereciveis</p>
            </div>
    </div>

  </div>
</div>
</div>


<div class="modal" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Fraldas Geriatricas</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body ">
        <div class="container">
            <div class="row">
                <div class="col">
                    <img src="<?php echo e(Vite::asset('resources/img/Fraldas.png')); ?>" alt="" width="250px"alt="..." height="230px">
                </div>
                <div class="col">
                    <div class="descricao">
                        <p>Estamos arrecadando agasalhos e roupas de frio em geral.
                        Para mais informações, entre em contato com nossa ONG.</p>
                </div>
                </div>
            </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Sair</button>
        <a type="button" class="btn btn-primary" href="<?php echo e(Route('RealizarDoacaoMaterial')); ?>">Doar</a>
      </div>
    </div>
  </div>
</div>

<br><br><br>
<br>
            <!--Rodapé-->
            <footer class="main-footer">
    <a class="QS" href="<?php echo e(Route('Informacoes')); ?>">Quem somos?</a>
    <a class="Info" href="<?php echo e(Route('Informacoes')); ?>">Informações</a>
    <a href=""><img src="<?php echo e(Vite::asset('resources/img/instagram.png')); ?>" class="img1-footer"></a>
    <a href=""><img src="<?php echo e(Vite::asset('resources/img/linkedin.png')); ?>" class="img2-footer"></a>
   </footer>

        <!--fim do Rodapé-->
</body><br><br>

</html><?php /**PATH C:\Users\guilherme\Hope_in_Life\Projeto_TCC_Hope_In_Life\resources\views/index.blade.php ENDPATH**/ ?>