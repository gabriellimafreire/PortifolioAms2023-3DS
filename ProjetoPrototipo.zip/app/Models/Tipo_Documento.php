<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Tipo_Documento extends Model
{
    use HasFactory;

    protected $table = 'Certidao';

    protected $fillable = [
        'NumeroDocumento',
        'Descricao'
    ];
}
