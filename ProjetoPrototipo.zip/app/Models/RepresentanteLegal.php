<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RepresentanteLegal extends Model
{
    use HasFactory;

    protected $table = 'Representante_Legal';

    public $timestamps = false;

    protected $fillable = [

        'NomeCompleto',
        'DataNascimento',
        'CPF',
        'RG',
        'Endereco',
        'Email',
        'NomeFotoPerfil'

    ];

    public function Telefone_Representante(){
        return $this->hasMany(Telefone_Representante::class);
    }
}
