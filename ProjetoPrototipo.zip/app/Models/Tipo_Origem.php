<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Tipo_Origem extends Model
{
    use HasFactory;

    protected $table = 'Tipo_Origem';

    public $timestamps = false;
    
    protected $fillable = [
        'id',
        'id_doador',
        'DataFundNasc',
        'Descricao'
    ];
}
