<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Foundation\Auth\User;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class Doador extends User
{
    use HasApiTokens, HasFactory, Notifiable;

    protected $table = 'Doador';

    protected $guard = 'Doador';

    protected $fillable = [
        'id_doador',
        'Nome',
        'id_tipoDataOrigem',
        'Endereco',
        'email',
        'EnderecoFotoPerfil',
        'password'
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function Telefone(): HasMany {
        return $this->hasMany(Telefone_Doador::class);
    }

    public function Cartao() : HasMany {
        return $this->hasMany(Cartao::class);
    }

    public function Preferencias() : HasMany {
        return $this->hasMany(Preferencia::class);
    }

    public function Tipo_Documento(): HasMany {
        return $this->hasMany(Tipo_Documento::class);
    }

    public function Tipo_Origem(): HasOne{
        return $this->hasOne(Tipo_Origem::class);
    }

}
