<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Foundation\Auth\User;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class Ong extends User
{
    use HasApiTokens, HasFactory, Notifiable;

    protected $table = 'Ong';

    protected $guard = 'Ong';

    protected $fillable = [
        'seguimento_id',
        'representante_id',
        'NomeFantasia',
        'DataFundacao',
        'CNPJ',
        'HoraDia',
        'SobreOng',
        'LocalFotoPerfil',
        'email',
        'password'

    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',

    ];

    public function Telefone_Ong(): HasMany{

        return $this->HasMany(Telefone_Ong::class);

    }
    public function Endereco_Ong(){

        return $this->hasMany(Endereco::class);

    }

    public function Seguimento(){
        return $this->hasMany(Seguimento::class);
    }
    
    
}
