<?php

namespace App\Http\Controllers;

use App\Models\Doacoes;
use Illuminate\Http\Request;

class DoacoesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Doacoes  $doacoes
     * @return \Illuminate\Http\Response
     */
    public function show(Doacoes $doacoes)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Doacoes  $doacoes
     * @return \Illuminate\Http\Response
     */
    public function edit(Doacoes $doacoes)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Doacoes  $doacoes
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Doacoes $doacoes)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Doacoes  $doacoes
     * @return \Illuminate\Http\Response
     */
    public function destroy(Doacoes $doacoes)
    {
        //
    }
}
