<?php

namespace App\Http\Controllers;

use App\Models\Doador;
use App\Models\Preferencia;
use App\Models\Telefone_Doador;
use App\Models\Tipo_Documento;
use App\Models\Tipo_Origem;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rules\Password as RulesPassword;

class DoadorController extends Controller
{
    public function cadastrarDoadorView(){

        return view('cadastrarDoador');

    }
    public function cadastrarDoador(Request $request){


        $dados = Validator::make(

            $request->all(),
            [
                'Nome' => 'required|string|min:10|max:55',
                'Email' => 'required|string|min:15|max:60|unique:doador|unique:ong',
                'Data' => 'required|Date',
                'Preferencias' =>'required|string',
                'Descricaotelefone' => 'required|string|max:10',
                'Endereco' =>'required|string|min:20|max:70',
                'CPF' => 'required|string|min:14|max:15',
                'RG' => 'required|string|min:12|max:17',
                'Telefone' => 'required|string|min:13|max:15',
                'Senha' => ['required', RulesPassword::min(7)->mixedCase()->symbols()]
            ]
        )->validate();

        // cadastrar tipo de origem

        $Tipo_Origem = new Tipo_Origem();

        $Tipo_Origem->DataFundNasc = $dados['Data'];

        $Tipo_Origem->Descricao = "Nascimento";

        $Tipo_Origem->save();

        // cadastrar doador

        $Doador = new Doador();

        $Doador->Nome = $request->Nome;

        $Doador->email = $request->Email;

        $Doador->endereco = $request->Endereco;

        $Doador->password = Hash::make($dados['Senha']);;

        $Doador->Tipo_Origem_Id = $Tipo_Origem->id;

        $Doador->EnderecoFotoPerfil = "teste";

        $Doador->save();

        // cadastrar telefone

        $Doador->Telefone()->create([
            'NumeroTelefone' => $request->Telefone,
            'Descricao' => $request->Descricaotelefone
        ]);

        // cadastrar RG

        $Doador->Tipo_Documento()->create([
            'NumeroDocumento' => $request->RG,
            'Descricao' => "RG"
        ]);

        // cadastrar CPF

        $Doador->Tipo_Documento()->create([
            'NumeroDocumento' => $request->CPF,
            'Descricao' => "CPF"
        ]);

        //cadastrar Preferencia

        $Doador->Preferencias()->create([
            'Seguimento' => $request->Preferencias,
            'seguimento_id' => 1

        ]);


        if(Auth::guard('Doador')->attempt(['email' => $Doador->email, 'password' => $dados['Senha']])){
            redirect('/homeDoador');
        }else{
            return back()->withErrors("Erro ao realizar cadastro");
        }



    }
}
